import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.englishtalkers.Usuario;
public class BancoDeDados extends SQLiteOpenHelper{
    private static final int VERSAO = 1;
    private static final String BANCO_DE_DADOS = "bd_usuario";

    private static final String TABELA_USUARIO = "tb_usuario";

    private static final String COLUNA_IDADE = "idade";
    private static final String COLUNA_NOME = "nome";
    private static final String COLUNA_EMAIL = "email";
    private static final String COLUNA_SENHA = "senha";
    private static final String COLUNA_PAIS = "pais";
    private static final String COLUNA_DIALOGO = "dialogo";
    private static final String COLUNA_CICLO = "ciclo";

    public BancoDeDados(@Nullable Context context) {
        super(context, BANCO_DE_DADOS, null, VERSAO);
    }



    public void onCreate(SQLiteDatabase db) {

        String QUERY_COLUNA = "CREATE TABLE "+ TABELA_USUARIO + "("+ COLUNA_NOME + "TEXT, " + COLUNA_EMAIL +"TEXT PRIMARY KEY, " +
                COLUNA_IDADE + "INTEGER, " + COLUNA_SENHA + "TEXT, " + COLUNA_CICLO + "INTEGER, " + COLUNA_DIALOGO + "INTEGER, " + COLUNA_PAIS +
                " TEXT)";
        db.execSQL(QUERY_COLUNA);

    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    void addUsuario (Usuario usuario){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUNA_NOME, usuario.getNome());
        values.put(COLUNA_EMAIL, usuario.getEmail());
        values.put(COLUNA_IDADE, usuario.getIdade());
        values.put(COLUNA_SENHA, usuario.getSenha());
        values.put(COLUNA_CICLO, usuario.getCiclo());
        values.put(COLUNA_DIALOGO, usuario.getDialogo());
        values.put(COLUNA_PAIS, usuario.getPais());
        db.insert(TABELA_USUARIO, null, values);
        db.close();


    }
}
