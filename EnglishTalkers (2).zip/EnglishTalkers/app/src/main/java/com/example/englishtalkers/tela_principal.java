package com.example.englishtalkers;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class tela_principal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_principal);
    }
}
