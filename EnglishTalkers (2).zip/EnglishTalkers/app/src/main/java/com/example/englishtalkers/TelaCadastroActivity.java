package com.example.englishtalkers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;

public class TelaCadastroActivity extends AppCompatActivity {

    EditText senha, nome, idade, email, confirmar_senha;

    BancoDeDados db = new BancoDeDados(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_cadastro);
        senha = (EditText) findViewById(R.id.senha_editText);
        nome = (EditText) findViewById(R.id.nome_editText);
        idade = (EditText) findViewById(R.id.idade_editText);
        email = (EditText) findViewById(R.id.e_mail_editText);
        confirmar_senha = (EditText) findViewById((R.id.confirmarsenha_editText));
    }
    public void cadastrar (View view){
        Intent intent1 = new Intent(getApplicationContext(), tela_principal.class);
        if (senha.getText().toString().equals(confirmar_senha.getText().toString())){
            db.addUsuario(new Usuario(idade, email, senha, nome));
            Toast.makeText(TelaCadastroActivity.this, "Salvo Com Sucesso.", Toast.LENGTH_LONG).show();
            startActivity(intent1);

        }
        else{
            Toast.makeText(TelaCadastroActivity.this, "As senhas não coincidem.", Toast.LENGTH_LONG).show();
        }


        }





        }