package com.example.englishtalkers;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.EditText;

public class Tela_login extends AppCompatActivity {
    EditText email, senha;
    BancoDeDados db = new BancoDeDados(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_login);
        email = (EditText) findViewById(R.id.editText_email);
        senha = (EditText) findViewById(R.id.edittext_Senha);



    }


    }

