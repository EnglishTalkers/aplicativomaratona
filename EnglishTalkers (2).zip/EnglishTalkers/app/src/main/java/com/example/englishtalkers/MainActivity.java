package com.example.englishtalkers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        }
    public void login(View view) {
        Intent intent1 = new Intent(getApplicationContext(), Tela_login.class);
        startActivity(intent1);
    }
    public void cadastro (View view){
        Intent intent2 = new Intent(getApplicationContext(), TelaCadastroActivity.class);
        startActivity(intent2);
    }
        }
