package com.example.englishtalkers;

import android.widget.EditText;

public class Usuario {
    //var
    int idade;
    String email;
    String senha;
    String pais;
    String nome;
    int ciclo;
    int dialogo;



    public Usuario(EditText idade, EditText email, EditText senha, EditText nome) {

    }
    public Usuario (int _idade, String _email, String _senha, String _nome){
        this.idade = _idade;
        this.email = _email;
        this.senha = _senha;
        this.nome = _nome;
        this.pais = "Inglaterra";
        this.ciclo = 1;
        this.dialogo = 1;


    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public int getCiclo() {
        return ciclo;
    }

    public String getNome (){
        return nome;
    }
    public void setNome (){
        this.nome = nome;
    }

    public void setCiclo(int ciclo) {
        this.ciclo = ciclo;
    }

    public int getDialogo() {
        return dialogo;
    }

    public void setDialogo(int dialogo) {
        this.dialogo = dialogo;
    }
}
